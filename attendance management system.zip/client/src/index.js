import React from 'react';
import {StrictMode} from 'react';
import App from './App'
import ReactDOM from 'react-dom/client';
import './index.css';

 
ReactDOM.render(<p>

    <App/>

</p>, document.getElementById('root'));

